package pojo;

public class Section {

	private int Section_id;
	private String Section_name;
	
	public int getSection_id() {
		return Section_id;
	}
	public void setSection_id(int section_id) {
		Section_id = section_id;
	}
	public String getSection_name() {
		return Section_name;
	}
	public void setSection_name(String section_name) {
		Section_name = section_name;
	}
	
	
	
}
