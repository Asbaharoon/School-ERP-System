package pojo;


public class Admin {

	private int Admin_id;
	private String Admin_name;
	private String Admin_pass;

	

	public int getAdmin_id() {
		return Admin_id;
	}

	public void setAdmin_id(int admin_id) {
		Admin_id = admin_id;
	}

	public String getAdmin_name() {
		return Admin_name;
	}

	public void setAdmin_name(String admin_name) {
		Admin_name = admin_name;
	}

	public String getAdmin_pass() {
		return Admin_pass;
	}

	public void setAdmin_pass(String admin_pass) {
		Admin_pass = admin_pass;
	}

}
