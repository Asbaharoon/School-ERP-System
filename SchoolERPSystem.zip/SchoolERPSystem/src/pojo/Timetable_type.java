package pojo;

public class Timetable_type {

	private int tt_id;
	private String tt_name;
	public int getTt_id() {
		return tt_id;
	}
	public void setTt_id(int tt_id) {
		this.tt_id = tt_id;
	}
	public String getTt_name() {
		return tt_name;
	}
	public void setTt_name(String tt_name) {
		this.tt_name = tt_name;
	}
	
	
	
}
